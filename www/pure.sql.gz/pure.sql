-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 15 2015 г., 09:57
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `mh`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `part` varchar(128) DEFAULT NULL COMMENT 'Часть url определяющая тип, например quick_start/branching',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер автора',
  `parent_id` int(11) DEFAULT '0' COMMENT 'Номер родительского комментария',
  `title` varchar(128) DEFAULT NULL COMMENT 'Заголовок',
  `body` text COMMENT 'Текст комментария',
  `date_modify` datetime DEFAULT NULL COMMENT 'Время изменения',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `is_accept` int(11) DEFAULT '0' COMMENT 'Комментарий прошел модерацию',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `pwd` varchar(32) DEFAULT NULL COMMENT 'пароль',
  `email` varchar(64) DEFAULT NULL COMMENT 'email',
  `guest_id` varchar(32) DEFAULT NULL COMMENT 'md5( ip datetime) анонимного пользователя загрузившего файл',
  `last_access_time` datetime DEFAULT NULL COMMENT 'время последнего обращения к файлу',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `name` varchar(64) DEFAULT NULL COMMENT 'Имя пользователя',
  `surname` varchar(64) DEFAULT NULL COMMENT 'Фамилия пользователя',
  `role` int(11) DEFAULT '0' COMMENT 'Роль пользователя 0 - пользователь 1 - модератор - 2 - админ',
  `current_task` varchar(7) DEFAULT NULL COMMENT 'Выбранная в данный момент задача формат: Вариант:Задание',
  `recovery_hash` varchar(32) DEFAULT NULL COMMENT 'Хэш md5 для восстановления пароля',
  `recovery_hash_created` datetime DEFAULT NULL COMMENT 'Время которое хеш действителен',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `pwd`, `email`, `guest_id`, `last_access_time`, `is_deleted`, `date_create`, `delta`, `name`, `surname`, `role`, `current_task`, `recovery_hash`, `recovery_hash_created`) VALUES
(1, NULL, NULL, 'd3fad46b24979d15fe635083cd324852', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
