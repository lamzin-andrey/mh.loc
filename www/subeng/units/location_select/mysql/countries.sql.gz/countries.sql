-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 07 2015 г., 14:55
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `gz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `country_name` varchar(64) DEFAULT NULL COMMENT 'Название страны',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `is_moderate` int(11) DEFAULT '0' COMMENT 'Промодерирован или нет.',
  `codename` varchar(128) DEFAULT NULL,
  `continent` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=246 ;

--
-- Дамп данных таблицы `countries`
--

INSERT INTO `countries` (`id`, `country_name`, `is_deleted`, `delta`, `is_moderate`, `codename`, `continent`) VALUES
(1, 'Белоруссия', 0, 1, 1, 'belorussiya', 2),
(2, 'Казахстан', 0, 2, 1, 'kazahstan', 1),
(3, 'Россия', 0, 3, 1, 'rossiya', 2),
(4, 'Украина', 0, 4, 1, 'ukraina', 1),
(29, 'Аргентина', 0, 27, 1, 'argentina', 6),
(30, 'Армения', 0, 28, 1, 'armeniya', 1),
(31, 'Афганистан', 0, 29, 1, 'afganistan', 1),
(33, 'Болгария', 0, 30, 1, 'bolgariya', 2),
(34, 'Ватикан', 0, 32, 1, 'vatikan', 2),
(36, 'Венгрия', 0, 33, 1, 'vengriya', 2),
(35, 'Венесуэла', 0, 34, 1, 'venesuеla', 6),
(28, 'Вьетнам', 0, 35, 1, 'vetnam', 1),
(45, 'Гвинея', 0, 36, 1, 'gvineya', 3),
(37, 'Дания', 0, 37, 1, 'daniya', 2),
(38, 'Доминиканская республика', 0, 38, 1, 'dominikanskaya_respublika', 5),
(39, 'Египет', 0, 39, 1, 'egipet', 3),
(40, 'Зимбабве', 0, 40, 1, 'zimbabve', 3),
(43, 'Индия', 0, 41, 1, 'indiya', 1),
(41, 'Ирак', 0, 42, 1, 'irak', 1),
(42, 'Иран', 0, 43, 1, 'iran', 1),
(44, 'Йемен', 0, 44, 1, 'iemen', 1),
(48, 'Камбоджа', 0, 45, 1, 'kambodja', 1),
(46, 'Катар', 0, 46, 1, 'katar', 1),
(49, 'Колумбия', 0, 47, 1, 'kolumbiya', 6),
(47, 'Конго', 0, 48, 1, 'kongo', 3),
(50, 'Люксембург', 0, 49, 1, 'lyuksemburg', 2),
(27, 'Чили', 0, 50, 1, 'chili', 6),
(54, 'Узбекистан', 0, 51, 1, 'uzbekistan', 1),
(55, 'Австрия', 0, 52, 1, 'avstriya', 2),
(56, 'Албания', 0, 53, 1, 'albaniya', 2),
(57, 'Андорра', 0, 54, 1, 'andorra', 2),
(58, 'Бельгия', 0, 55, 1, 'belgiya', 2),
(59, 'Босния и Герцеговина', 0, 56, 1, 'bosniya_i_gercegovina', 2),
(60, 'Великобритания', 0, 57, 1, 'velikobritaniya', 2),
(62, 'Германия', 0, 59, 1, 'germaniya', 2),
(63, 'Гибралтар', 0, 60, 1, 'gibraltar', 2),
(65, 'Гренландия', 0, 62, 1, 'grenlandiya', 2),
(66, 'Греция', 0, 63, 1, 'greciya', 2),
(67, 'Ирландия', 0, 64, 1, 'irlandiya', 2),
(68, 'Исландия', 0, 65, 1, 'islandiya', 2),
(69, 'Испания', 0, 66, 1, 'ispaniya', 2),
(70, 'Италия', 0, 67, 1, 'italiya', 2),
(71, 'Кипр', 0, 68, 1, 'kipr', 2),
(72, 'Латвия', 0, 69, 1, 'latviya', 2),
(73, 'Литва', 0, 70, 1, 'litva', 2),
(74, 'Лихтенштейн', 0, 71, 1, 'lihtenshtein', 2),
(75, 'Македония', 0, 72, 1, 'makedoniya', 2),
(76, 'Мальта', 0, 73, 1, 'malta', 2),
(77, 'Монако', 0, 74, 1, 'monako', 2),
(78, 'Нидерланды', 0, 75, 1, 'niderlandi', 2),
(79, 'Норвегия', 0, 76, 1, 'norvegiya', 2),
(80, 'Польша', 0, 77, 1, 'polsha', 2),
(81, 'Португалия', 0, 78, 1, 'portugaliya', 2),
(82, 'Республика Сан-Марино', 0, 79, 1, 'respublika_san-marino', 2),
(83, 'Румыния', 0, 80, 1, 'ruminiya', 2),
(84, 'Сербия', 0, 81, 1, 'serbiya', 2),
(85, 'Словакия', 0, 82, 1, 'slovakiya', 2),
(86, 'Словения', 0, 83, 1, 'sloveniya', 2),
(87, 'Финляндия', 0, 84, 1, 'finlyandiya', 2),
(88, 'Франция', 0, 85, 1, 'franciya', 2),
(89, 'Хорватия', 0, 86, 1, 'horvatiya', 2),
(90, 'Черногория', 0, 87, 1, 'chernogoriya', 2),
(91, 'Чехия', 0, 88, 1, 'chehiya', 2),
(92, 'Швейцария', 0, 89, 1, 'shveicariya', 2),
(93, 'Швеция', 0, 90, 1, 'shveciya', 2),
(94, 'Эстония', 0, 91, 1, 'estoniya', 2),
(95, 'Бангладеш', 0, 92, 1, 'bangladesh', 1),
(96, 'Бахрейн', 0, 93, 1, 'bahrein', 1),
(97, 'Бруней', 0, 94, 1, 'brunei', 1),
(98, 'Бутан', 0, 95, 1, 'butan', 1),
(99, 'Восточный Тимор', 0, 96, 1, 'vostochnii_timor', 1),
(100, 'Гонконг', 0, 97, 1, 'gonkong', 1),
(101, 'Израиль', 0, 98, 1, 'izrail', 1),
(102, 'Иордания', 0, 99, 1, 'iordaniya', 1),
(103, 'Китай', 0, 100, 1, 'kitai', 1),
(104, 'Корейская Народно-Демократическая Республика', 0, 101, 1, 'koreiskaya_narodno-demokraticheskaya_respublika', 1),
(105, 'Кувейт', 0, 102, 1, 'kuveit', 1),
(106, 'Лаос', 0, 103, 1, 'laos', 1),
(107, 'Ливан', 0, 104, 1, 'livan', 1),
(108, 'Малайзия', 0, 105, 1, 'malaiziya', 1),
(109, 'Мальдивы', 0, 106, 1, 'maldivi', 1),
(110, 'Монголия', 0, 107, 1, 'mongoliya', 1),
(111, 'Мьянма', 0, 108, 1, 'myanma', 1),
(112, 'Непал', 0, 109, 1, 'nepal', 1),
(113, 'Объединенные Арабские Эмираты', 0, 110, 1, 'obedinennie_arabskie_emirati', 1),
(114, 'Оман', 0, 111, 1, 'oman', 1),
(115, 'Пакистан', 0, 112, 1, 'pakistan', 1),
(116, 'Палестинская автономия', 0, 113, 1, 'palestinskaya_avtonomiya', 1),
(117, 'Республика Корея', 0, 114, 1, 'respublika_koreya', 1),
(118, 'Республика Сингапур', 0, 115, 1, 'respublika_singapur', 1),
(119, 'Саудовская Аравия', 0, 116, 1, 'saudovskaya_araviya', 1),
(120, 'Сирия', 0, 117, 1, 'siriya', 1),
(121, 'Судан', 0, 118, 1, 'sudan', 1),
(122, 'Таиланд', 0, 119, 1, 'tailand', 1),
(123, 'Тайвань', 0, 120, 1, 'taivan', 1),
(124, 'Турция', 0, 121, 1, 'turciya', 1),
(125, 'Шри-Ланка', 0, 122, 1, 'shri-lanka', 1),
(126, 'Япония', 0, 123, 1, 'yaponiya', 1),
(127, 'Алжирская Народная Демократическая Республика', 0, 124, 1, 'aljirskaya_narodnaya_demokraticheskaya_respublika', 3),
(128, 'Ангола', 0, 125, 1, 'angola', 3),
(129, 'Бенин', 0, 126, 1, 'benin', 3),
(130, 'Ботсвана', 0, 127, 1, 'botsvana', 3),
(131, 'Буркина-Фасо', 0, 128, 1, 'burkina-faso', 3),
(132, 'Бурунди', 0, 129, 1, 'burundi', 3),
(133, 'Габон', 0, 130, 1, 'gabon', 3),
(134, 'Гамбия', 0, 131, 1, 'gambiya', 3),
(135, 'Гана', 0, 132, 1, 'gana', 3),
(137, 'Гвинея-Бисау', 0, 134, 1, 'gvineya-bisau', 3),
(138, 'Демократическая Республика Конго', 0, 135, 1, 'demokraticheskaya_respublika_kongo', 3),
(139, 'Замбия', 0, 136, 1, 'zambiya', 3),
(140, 'Кабо-Верде', 0, 137, 1, 'kabo-verde', 3),
(141, 'Камерун', 0, 138, 1, 'kamerun', 3),
(142, 'Кения', 0, 139, 1, 'keniya', 3),
(143, 'Коморские острова', 0, 140, 1, 'komorskie_ostrova', 3),
(144, 'Лесото', 0, 141, 1, 'lesoto', 3),
(145, 'Либерия', 0, 142, 1, 'liberiya', 3),
(146, 'Ливия', 0, 143, 1, 'liviya', 3),
(147, 'Маврикий', 0, 144, 1, 'mavrikii', 3),
(148, 'Мавритания', 0, 145, 1, 'mavritaniya', 3),
(149, 'Мадагаскар', 0, 146, 1, 'madagaskar', 3),
(150, 'Малави', 0, 147, 1, 'malavi', 3),
(151, 'Мали', 0, 148, 1, 'mali', 3),
(152, 'Марокко', 0, 149, 1, 'marokko', 3),
(153, 'Мозамбик', 0, 150, 1, 'mozambik', 3),
(154, 'Намибия', 0, 151, 1, 'namibiya', 3),
(155, 'Нигер', 0, 152, 1, 'niger', 3),
(156, 'Нигерия', 0, 153, 1, 'nigeriya', 3),
(157, 'Республика Джибути', 0, 154, 1, 'respublika_djibuti', 3),
(159, 'Руанда', 0, 156, 1, 'ruanda', 3),
(160, 'Сан-Томе и Принсипи', 0, 157, 1, 'san-tome_i_prinsipi', 3),
(161, 'Свазиленд', 0, 158, 1, 'svazilend', 3),
(162, 'Сейшельские острова', 0, 159, 1, 'seishelskie_ostrova', 3),
(163, 'Сенегал', 0, 160, 1, 'senegal', 3),
(164, 'Сомали', 0, 161, 1, 'somali', 3),
(165, 'Сьерра-Леоне', 0, 162, 1, 'serra-leone', 3),
(166, 'Танзания', 0, 163, 1, 'tanzaniya', 3),
(167, 'Того', 0, 164, 1, 'togo', 3),
(168, 'Тунисская Республика', 0, 165, 1, 'tunisskaya_respublika', 3),
(169, 'Уганда', 0, 166, 1, 'uganda', 3),
(170, 'Центрально-Африканская Республика', 0, 167, 1, 'centralno-afrikanskaya_respublika', 3),
(171, 'Чад', 0, 168, 1, 'chad', 3),
(172, 'Экваториальная Гвинея', 0, 169, 1, 'ekvatorialnaya_gvineya', 3),
(173, 'Эритрея', 0, 170, 1, 'eritreya', 3),
(174, 'Эфиопия', 0, 171, 1, 'efiopiya', 3),
(175, 'Южно-Африканская Республика', 0, 172, 1, 'yujno-afrikanskaya_respublika', 3),
(176, 'Австралия', 0, 173, 1, 'avstraliya', 7),
(177, 'Вануату', 0, 174, 1, 'vanuatu', 7),
(178, 'Индонезия', 0, 175, 1, 'indoneziya', 7),
(179, 'Кирибати', 0, 176, 1, 'kiribati', 7),
(180, 'Королевство Тонга', 0, 177, 1, 'korolevstvo_tonga', 7),
(181, 'Науру', 0, 178, 1, 'nauru', 7),
(182, 'Новая Зеландия', 0, 179, 1, 'novaya_zelandiya', 7),
(183, 'Острова Кука', 0, 180, 1, 'ostrova_kuka', 7),
(184, 'Папуа - Новая Гвинея', 0, 181, 1, 'papua_-_novaya_gvineya', 7),
(185, 'Самоа', 0, 182, 1, 'samoa', 7),
(186, 'Фиджи', 0, 183, 1, 'fidji', 7),
(187, 'Филиппины', 0, 184, 1, 'filippini', 7),
(188, 'Багамские острова', 0, 185, 1, 'bagamskie_ostrova', 5),
(189, 'Гаити', 0, 186, 1, 'gaiti', 5),
(190, 'Гваделупа', 0, 187, 1, 'gvadelupa', 5),
(191, 'Гондурас', 0, 188, 1, 'gonduras', 5),
(192, 'Канада', 0, 189, 1, 'kanada', 5),
(193, 'Коста-Рика', 0, 190, 1, 'kosta-rika', 5),
(194, 'Куба', 0, 191, 1, 'kuba', 5),
(195, 'Мексика', 0, 192, 1, 'meksika', 5),
(196, 'Никарагуа', 0, 193, 1, 'nikaragua', 5),
(197, 'Пуэрто-Рико', 0, 194, 1, 'puеrto-riko', 5),
(198, 'Республика Гватемала', 0, 195, 1, 'respublika_gvatemala', 5),
(199, 'Республика Панама', 0, 196, 1, 'respublika_panama', 5),
(200, 'Сальвадор', 0, 197, 1, 'salvador', 5),
(201, 'Соединенные Штаты Америки', 0, 198, 1, 'soedinennie_shtati_ameriki', 5),
(202, 'Тринидад и Тобаго', 0, 199, 1, 'trinidad_i_tobago', 5),
(203, 'Ямайка', 0, 200, 1, 'yamaika', 5),
(204, 'Белиз', 0, 201, 1, 'beliz', 6),
(205, 'Боливия', 0, 202, 1, 'boliviya', 6),
(206, 'Бразилия', 0, 203, 1, 'braziliya', 6),
(207, 'Гайана', 0, 204, 1, 'gaiana', 6),
(208, 'Доминика', 0, 205, 1, 'dominika', 6),
(209, 'Парагвай', 0, 206, 1, 'paragvai', 6),
(210, 'Перу', 0, 207, 1, 'peru', 6),
(211, 'Сент-Винсент и Гренадины', 0, 208, 1, 'sent-vinsent_i_grenadini', 6),
(212, 'Суринам', 0, 209, 1, 'surinam', 6),
(213, 'Уругвай', 0, 210, 1, 'urugvai', 6),
(214, 'Эквадор', 0, 211, 1, 'ekvador', 6),
(245, 'Туркменистан', 0, 218, 1, 'turkmenistan', 1),
(243, 'Молдова', 0, 216, 1, 'moldova', 2),
(244, 'Таджикистан', 0, 217, 1, 'tadjikistan', 1),
(242, 'Кыргызстан', 0, 215, 1, 'kirgizstan', 1),
(241, 'Грузия', 0, 214, 1, 'gruziya', 1),
(240, 'Азербайджан', 0, 213, 1, 'azerbaidjan', 1),
(239, 'Абхазия', 0, 212, 1, 'abhaziya', 2);

--
-- Триггеры `countries`
--
DROP TRIGGER IF EXISTS `bicountries`;
DELIMITER //
CREATE TRIGGER `bicountries` BEFORE INSERT ON `countries`
 FOR EACH ROW BEGIN
 SET NEW.delta = (SELECT max(delta) FROM `countries`) + 1;
 IF NEW.delta IS NULL THEN
     SET NEW.delta = 1;
 END IF;
END
//
DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
