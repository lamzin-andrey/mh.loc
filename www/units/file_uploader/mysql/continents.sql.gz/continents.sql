-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 07 2015 г., 14:55
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `gz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `continents`
--

DROP TABLE IF EXISTS `continents`;
CREATE TABLE IF NOT EXISTS `continents` (
  `id` int(11) NOT NULL COMMENT 'Первичный ключ.',
  `continent_name` varchar(64) DEFAULT NULL COMMENT 'Название континента',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `continents`
--

INSERT INTO `continents` (`id`, `continent_name`, `is_deleted`, `delta`) VALUES
(1, 'Азия', 0, 1),
(2, 'Европа', 0, 2),
(3, 'Африка', 0, 3),
(4, 'Австралия', 0, 4),
(5, 'Америка', 0, 5),
(6, 'Латинская Америка', 0, 6),
(7, 'Австралия и Океания', 0, 7);

--
-- Триггеры `continents`
--
DROP TRIGGER IF EXISTS `bicontinents`;
DELIMITER //
CREATE TRIGGER `bicontinents` BEFORE INSERT ON `continents`
 FOR EACH ROW BEGIN
 SET NEW.delta = (SELECT max(delta) FROM `continents`) + 1;
 IF NEW.delta IS NULL THEN
     SET NEW.delta = 1;
 END IF;
END
//
DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
